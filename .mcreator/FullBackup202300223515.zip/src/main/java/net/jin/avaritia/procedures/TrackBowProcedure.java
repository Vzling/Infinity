package net.jin.avaritia.procedures;

import net.minecraft.world.entity.Entity;

public class TrackBowProcedure {
	public static void execute() {
		Entity position = null;
	}
}
