
package net.jin.avaritia.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.jin.avaritia.entity.BlackHoleEntity;
import net.jin.avaritia.client.model.Modelblackhole;

public class BlackHoleRenderer extends MobRenderer<BlackHoleEntity, Modelblackhole<BlackHoleEntity>> {
	public BlackHoleRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelblackhole(context.bakeLayer(Modelblackhole.LAYER_LOCATION)), 0f);
	}

	@Override
	public ResourceLocation getTextureLocation(BlackHoleEntity entity) {
		return new ResourceLocation("avaritia:textures/entities/blockhole.png");
	}
}
